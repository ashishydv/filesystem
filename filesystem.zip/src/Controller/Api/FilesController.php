<?php
namespace App\Controller\Api;

use App\Controller\Api\AppController;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;
use Cake\Network\Exception\ForbiddenException;
use App\Error\Exception\ValidationException;

use Cake\Filesystem\Folder;
use Cake\Filesystem\File;

use Cake\Http\Exception\NotImplementedException;

/**
 *
 * This controller will render views from Template/Posts/
 *
 */
class FilesController extends AppController
{
	public function initialize(){
        parent::initialize();
	}

	public function beforeFilter(Event $event){
		parent::beforeFilter($event);
		//$this->Security->config('unlockedActions', ['list','rename','create']);
    }


    private function directoryCheck($pathToUserDir){
        //$pathToUserDir = DIR_PATH . $username;
        if(!file_exists( $pathToUserDir )) mkdir($pathToUserDir, 0777);
    }

    public function list(){
        if(!$this->request->is(['ajax','post'])) die;
        if(!isset($this->request->data['username'])) die;

 
        //print_r( $this->request->data ); die;
        $username = $this->request->data['username'];
        $curdir = $this->request->data['curdir'];

        $pathToUserDir = DIR_PATH . $username. DS. $curdir;
        $this->directoryCheck($pathToUserDir); // if user direcotry not exist create new

        $dir = new Folder( $pathToUserDir );
        $files = $dir->read(true);
        
        //$files = scandir($pathToUserDir);

        $result = [];
        foreach($files[0] as $name){
            array_push($result, ['type' => 'folder', 'name' => $name, 'path' => $curdir] );
        }

        foreach($files[1] as $name){
            array_push($result, ['type' => 'file', 'name' => $name, 'path' => $curdir] );
        }

        //print_r( $files ); die;
        $this->set(['files' => $result,
            '_serialize' => ['files']    
        ]);
    }


    public function rename(){

        if( $this->request->is(['ajax', 'post', 'put']) ){

            $reqdata = $this->request->data;

            $username = $this->request->data['username'];
            $fileName = $this->request->data['fileName'];
            $newFileName = $this->request->data['newFileName'];
            $path = $this->request->data['path'];
            if (strlen($path) > 0) $path =  $path . DS;
            
            $pathToUserDir = DIR_PATH . $username. DS. $path;
            if (rename($pathToUserDir . $fileName, $pathToUserDir . $newFileName) ){

                $this->set(['success' => 'success',
                    '_serialize' => ['success']    
                ]);

            }else{
                throw new NotImplementedException('Failed to rename');
            }
        }
    }

    public function delete(){

        if($this->request->is(['ajax', 'post', 'delete'])){

            $username = $this->request->data['username'];
            $fileName = $this->request->data['fileName'];
            $path = $this->request->data['path'];
            if (strlen($path) > 0) $path =  $path . DS;

            $pathToFile = DIR_PATH . $username. DS. $path. $fileName;
            $file = null;
            if (is_dir($pathToFile) ){
                $file = new Folder($pathToFile);
            }else{
                $file = new File($pathToFile);
            }

            if( $file->delete() ){
                $this->set(['success' => 'success',
                    '_serialize' => ['success']    
                ]);
            }
        }
    }

    public function create(){

        if($this->request->is(['ajax', 'post', 'delete'])){

            $username = $this->request->data['username'];
            $fileName = $this->request->data['fileName'];
            $curdir = $this->request->data['curdir'];
            $type = $this->request->data['type'];
            if (strlen($curdir) > 0) $curdir =  $curdir . DS;
            $pathToFile = DIR_PATH . $username. DS. $curdir. $fileName;

            if($type == 'folder'){
                if(!file_exists( $pathToFile )) mkdir($pathToFile, 0777);
            }else if($type == 'file'){
                if(!file_exists($pathToFile)) file_put_contents($pathToFile, '');
            }

        }

    }

    public function search(){

        if($this->request->is(['ajax', 'post'])){

            $username = $this->request->data['username'];
            $fileName = $this->request->data['searchName'];
            $pathToFolder = DIR_PATH . $username;
            $dir = new Folder($pathToFolder);
            $files = $dir->findRecursive("($fileName).*");

            $result = [];
            foreach($files as $file){
                $newString = str_replace($pathToFolder, "", $file);
                $newString = trim($newString, "\\");
                $newString = explode("\\", $newString);

                $name = array_pop( $newString );
                $path = join("\\", $newString);
                array_push($result, ['name' => $name, 'path' => $path, 'type' => 'file']);
            }

            $this->set(['files' => $result,
                    '_serialize' => ['files']    
                ]);

        }

    }


}
