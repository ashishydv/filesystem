import { useState, useEffect } from 'react';
import Login from './Login';
import Logout from './Logout';
import FilesSearchBox from './FileSearch/FileSearchBox' 
import fetchFiles,{renameFileApi, deleteFileApi, newDirApi, searchFileApi} from './Api/api';
import FileList from './FilesList';

function App(){

  // application state
  const [username, setUsername] = useState('');
  const [filelist, setFileList] = useState([[]]);
  const [forceCallList, setForceCallList] = useState(0);
  const [curdir, setCurdir] = useState([]);
  useEffect( () => {
    if (username.length === 0) return;
    const res = fetchFiles(username, curdir);
    res.then(data => {
      setFileList(data.files);
    });

  },[username, curdir, forceCallList] );


  

  function handleOpenDir(index){
    if(filelist.length < index-1) return;
    const file = filelist[index];
    if(file.type === 'file') return;
    const newCurDir = curdir.slice();
    newCurDir.push(file.name);
    setCurdir( newCurDir )
  }

  function handleRenameSubmit(fileIndex, newFileName){
    if(filelist.length < fileIndex-1) return;
    const file = filelist[fileIndex];
    renameFileApi(username, file.name, newFileName, file.path)
      .then(res => {
        setForceCallList( prevValue => prevValue+1 ); 
      });
  }

  function handleNewDirSubmit(name, type){
    newDirApi(username, name, type, curdir)
      .then(res => {
        setForceCallList( prevValue => prevValue+1 ); 
      });
  }

  function handleDeleteSubmit(fileIndex){
    if(filelist.length < fileIndex-1) return;
    const file = filelist[fileIndex];
    deleteFileApi(username, file.name, file.path)
      .then(data => {
        setForceCallList( prevValue => prevValue+1 ); 
      })
  }

  function handleSearchRequest(name){
    if(name.length <= 0){
      setForceCallList( prevValue => prevValue+1 ); 
      return
    }
    searchFileApi(username, name)
    .then(data => {
      setFileList(data.files);
    })
  }

  let isLoggedIn = username.length !== 0;

  function renderAuth(){
    function handleLogin(username){
      setUsername(username)
    }
    function handleLogout(){
      setUsername('')
      setCurdir([]);
    }

    return (<div>
        { !isLoggedIn ? <Login onLoginClick={handleLogin} /> 
                      : <Logout onLogoutClick={handleLogout} />}
      </div>)
  }

  return (
    <div style={{margin: '20px'}}>
      {renderAuth()}
      { isLoggedIn && <FilesSearchBox searchRquest={handleSearchRequest} />}
      { isLoggedIn && <FileList itemList={filelist} 
        openDir={handleOpenDir} 
        renameSubmit={handleRenameSubmit} 
        deleteSubmit={handleDeleteSubmit}
        newDirSubmit={handleNewDirSubmit}
        /> }
    </div>
  )

}
export default App;
