import Button from '@mui/material/Button';
import LogoutIcon from '@mui/icons-material/Logout';

function Logout(props){
    return(
        <Button variant="outlined" startIcon={<LogoutIcon />} onClick={() => props.onLogoutClick()} >Logout</Button>
        
    );
}
export default Logout;