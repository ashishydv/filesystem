import React, {useState, useRef} from 'react';

import Paper from '@mui/material/Paper';
import InputBase from '@mui/material/InputBase';
import IconButton from '@mui/material/IconButton';
import SearchIcon from '@mui/icons-material/Search';

function FilesSearchBox(props){
    const searchFieldEl = useRef(null);
    
    function handleSearchSubmit(event){
        event.preventDefault();
        const value = searchFieldEl.current.value;
        props.searchRquest(value);
        
    }

    return (
        <Paper
            component="form"
            onSubmit = {handleSearchSubmit}
            sx={{ p: '2px 4px', display: 'flex', alignItems: 'center', width: 400, marginTop:5 }}
        >
        <InputBase
            sx={{ ml: 1, flex: 1 }}
            placeholder="Search Files"
            inputProps={{ 'aria-label': 'search files' }}
            inputRef={searchFieldEl}
        />
        <IconButton type="submit" sx={{ p: '10px' }} aria-label="search">
            <SearchIcon />
        </IconButton>
        </Paper>
    )

}
export {FilesSearchBox}
export default FilesSearchBox;