import React, {useState} from 'react';


function SearchResult(){

    

}

export default SearchResult;