import axios from 'axios';

const BASE_URL = 'http://localhost/filesystem/api/';

const LOGIN_URL = BASE_URL + 'pages/login';

const DIR_URL = BASE_URL + 'files/list';
const DIR_U = 'files/list';
const RENAME_URL = 'files/rename';
const DELETE_FILE_URL = 'files/delete';
const NEW_ITEM = 'files/create';
const SEARCH_ITEM = 'files/search';

const axiosInstance = axios.create({
  baseURL: BASE_URL,
  timeout: 1000,
  responseType: 'json',

});


// fetch file
function fetchFiles(username, curdir){
  console.log("Cur dir path:", curdir);
  return axiosInstance({
    method: 'post',
    url: DIR_U,
    data:{
      username: username,
      curdir: curdir.join('/')
    }
  })
    .then(res => {
        console.log(  "Axios Response: ", res );
        return res.data
    })
    .catch(function (error) {
      console.log(error.toJSON());
    });

}

function renameFileApi(username, fileName, newFileName, path){

  return axiosInstance({
    method: 'put',
    url: RENAME_URL,
    data:{
      username: username,
      fileName: fileName,
      newFileName: newFileName,
      path: path
    }
  })
    .then(res => {
        return res.data
    })
    .catch(function (error) {
      console.log(error.toJSON());
    });
}

function deleteFileApi(username, fileName, path){

  return axiosInstance({
    method: 'post',
    url: DELETE_FILE_URL,
    data:{
      username: username,
      fileName: fileName,
      path: path
    }
  })
    .then(res => {
        return res.data
    })
    .catch(function (error) {
      console.log(error.toJSON());
    });
}

function newDirApi(username, fileName, type, curdir){

  return axiosInstance({
    method: 'post',
    url: NEW_ITEM,
    data:{
      username: username,
      fileName: fileName,
      type: type,
      curdir: curdir.join('/')
    }
  })
  .then(res => {
    return res.data
  })
  .catch(function (error) {
    console.log(error.toJSON());
  });
}

function searchFileApi(username, searchName){
  return axiosInstance({
    method: 'post',
    url: SEARCH_ITEM,
    data:{
      username: username,
      searchName: searchName
    }
  })
  .then(res => {
    return res.data
  })
  .catch(function (error) {
    console.log(error.toJSON());
  });
}

export { fetchFiles, renameFileApi, deleteFileApi, newDirApi, searchFileApi }
export default fetchFiles;