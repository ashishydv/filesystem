import {useState, useRef} from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import FolderIcon from '@mui/icons-material/Folder';
import CreateNewFolderIcon from '@mui/icons-material/CreateNewFolder';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import UploadFileIcon from '@mui/icons-material/UploadFile';

import RenameDialog from './RenameDialog';
import DeleteDeialogBox from './DeleteDialogBox';

function FileList(props){

    console.log( "Files list: ",props.files );

    const [renameOpen, setRenameOpen] = useState(false);
    const [deleteOpen, setDeleteOpen] = useState(false);
    const [newDirectoryOpen, setNewDirectoryOpen] = useState(false);
    const [newFileType, setNewFileType] = useState(null); // types: folder, file
    
    const [selectedItem, setSelectedItem] = useState();
    const renameFieldEl = useRef(null);
    const newDirFieldEl = useRef(null);

    //const folders = props.folders;
    //const files = props.files;

    // dialogbox open handle functions
    function handleRenameOpen(fileIndex){
        setSelectedItem(fileIndex);
        setRenameOpen(true);
    };
    const handleRenameClose = () => {
        setSelectedItem(null);
        setRenameOpen(false);
    };
    function handleDeleteOpen(name){
        setSelectedItem(name);
        setDeleteOpen(true);
    };
    const handleDeleteClose = () => {
        setSelectedItem();
        setDeleteOpen(false);
    };
    function handleNewDirectoryOpen(type){
        setNewFileType(type)
        setNewDirectoryOpen(true)

    }
    const handleNewDirectoryClose = () => {
        setNewFileType(null);
        setNewDirectoryOpen(false);
    };


    // File operations
    function handleNewDirectorySubmit(){
        props.newDirSubmit(newDirFieldEl.current.value, newFileType)
        newDirFieldEl.current.value = '';
        handleNewDirectoryClose();
    }
    function handleRenameSubmit(){
        props.renameSubmit( selectedItem, renameFieldEl.current.value );
        handleRenameClose();
    }
    function handleDeleteSubmit(){
        props.deleteSubmit(selectedItem)
        handleDeleteClose();
    }
    function handleOpen(index){
        props.openDir(index)
    }
    
    const items = props.itemList.map((item, index) => {
        const icon = (item.type === 'folder')  ? <FolderIcon /> : <InsertDriveFileIcon />;
        return  (<tr key={index}>
            <td><Button startIcon={icon} href="#" onClick ={ () => handleOpen(index)} style={{textTransform: 'none'}}>{item.name}</Button  ></td>
            <td><Button startIcon={<EditIcon />} onClick={() => handleRenameOpen(index)}></Button></td>
            <td><Button startIcon={<DeleteIcon />} onClick={() => handleDeleteOpen(index)}></Button></td>
        </tr> );
    });
   
    return (
        <div style={{border: '1px solid #ddd', padding: '10px', marginTop: '20px'}}>
            <h3>Files:</h3>
            <div>
                <Button  variant="outlined" startIcon={<CreateNewFolderIcon />} onClick={() => handleNewDirectoryOpen('folder')}>New Directory</Button>
                &nbsp;
                <Button  variant="outlined" startIcon={<UploadFileIcon />} onClick={() => handleNewDirectoryOpen('file')}>New File</Button>
            </div>
            <table>{items}</table>

            { (selectedItem || selectedItem ===0 ) ? <RenameDialog
                open={renameOpen}
                handleClose={handleRenameClose}
                fieldRef={renameFieldEl}
                item={props.itemList[selectedItem]}
                handleSubmit={handleRenameSubmit}
            /> : null }

            { (selectedItem || selectedItem ===0 ) ? <DeleteDeialogBox
                open={deleteOpen}
                handleClose={handleDeleteClose}
                item={props.itemList[selectedItem]}
                handleSubmit={handleDeleteSubmit}
            /> : null }


            <Dialog open={newDirectoryOpen} onClose={handleNewDirectoryOpen}>
                <DialogTitle>New  {newFileType == 'folder' ? 'Directory' : 'File'}</DialogTitle>
                <DialogContent>
                    <TextField
                        autoFocus
                        margin="dense"
                        label="New Name"
                        type="text"
                        fullWidth
                        variant="standard"
                        inputRef={newDirFieldEl}
                    />
                </DialogContent>
                <DialogActions>
                <Button onClick={handleNewDirectoryClose}>Cancel</Button>
                <Button onClick={handleNewDirectorySubmit}>Create</Button>
                </DialogActions>
            </Dialog>
        </div>
    )
}
export default FileList